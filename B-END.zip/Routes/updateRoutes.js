const express=require('express')
const router=express.Router()
// const Update = require('../Controllers/UpdateController/updateController')
const Update=require('../Controllers/UpdateController/updateController')

router.post('/addUpdate',Update.addUpdate)
router.post('/getuserUpdate',Update.getUserUpdate)
router.delete('/deleteUpdate',Update.deleteUpdate)


module.exports=router
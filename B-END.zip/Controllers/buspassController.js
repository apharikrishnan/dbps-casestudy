const BusPass = require('../Models/BusPass')
const User = require('../Models/User')

exports.addBusPass = (req, res) => {

    User.findOne({ _id: req.body.user })
        .then((user) => {
            BusPass.create({
                user: user.id,
                yourfullname: req.body.yourfullname,
                yourdateofbirt: req.body.yourdateofbirt,
                yourage: req.body.yourage,
                youremailid: req.body.youremailid,
                yourpresentaddress: req.body.yourpresentaddress,
                yourmobileno: req.body.yourmobileno,
              
            }).then((data) => {
                console.log(data)
                res.send(data)
            }).catch((error) => {
                console.log(error)
            })
        })
        .catch((error) => {
            console.log(error)
        })
}

exports.getAllBusPass = (req, res) => {
    BusPass.find({})
        .then((data) => {
            res.send(data)
        }).catch((error) => {
            console.log(error)
        })
}

exports.getUser=(req,res)=>{
BusPass.find({id:req.body.id})
.populate('user')
.then((data)=>{
    // console.log(req.body.userID)
    res.send(data)
}).catch((err)=>{
    console.log(err)
}) 
}

exports.deleteOne=(req,res)=>{
    BusPass.remove({id:req.body._id})
    .then((data)=>{
        res.send(data)
    }).catch((error)=>{
        console.log(error)
    })
}
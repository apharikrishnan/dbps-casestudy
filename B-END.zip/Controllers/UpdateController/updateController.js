const Update=require('../../Models/Update')
const User=require('../../Models/User')

exports.addUpdate=(req,res)=>{
   User.findOne({_id:req.body.user})
   .then((user)=>{
       Update.create({
           user:user.id,
           email:req.body.email,
           mobileno:req.body.mobileno
        //    role:req.body.role,
        //    company:req.body.company,
        //    from:req.body.from,
        //    to:req.body.to,
        //    total:req.body.total
    }).then((data)=>{
        res.send(data)
    })
   }).catch((error)=>{
       console.log(error)
   })
}

exports.getUpdate=(req,res)=>{
    Update.find({})
    .then((data)=>{
        res.send(data)
    }).catch((error)=>{
        console.log(error)
    })
}



exports.getUserUpdate=(req,res)=>{
    Update.find({id:req.body.id})
    .populate('user')
    .then((data)=>{
        res.send(data)
    }).catch((error)=>{
        console.log(error)
    })
}

exports.deleteUpdate=(req,res)=>{
    Update.remove({id:req.body.id})
    .then((data)=>{
        res.send(data)
    }).catch((error)=>{
        console.log(error)
    })
}
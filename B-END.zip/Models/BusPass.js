const mongoose=require('mongoose')

const buspassSchema=mongoose.Schema({
    user:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'users'
    },
    yourfullname:{
        type:String,
        required:false
    },
    yourdateofbirt:{
        type:String,
        required:false
    },
    yourage:{
        type:String,
        required:false
    },
    youremailid:{
        type:String,
        required:false
    },
    yourpresentaddress:{
        type:String,
        required:false
    },
    yourmobileno:{
        type:Number,
        required:false
    },
    

})

module.exports =mongoose.model('buspass',buspassSchema)
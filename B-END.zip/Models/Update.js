const mongoose=require('mongoose')

const updateSchema=mongoose.Schema({
    user:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'users'
    },

        email:{
        type:String,
        required:true
    },

        mobileno:{
        type:Number,
        required:true
    },  

})

module.exports =mongoose.model('update',updateSchema)